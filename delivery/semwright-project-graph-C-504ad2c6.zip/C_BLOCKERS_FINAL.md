# C remaining integration blockers

## C09 — typed rebuild dispatch

Implemented today: bounded rebuild DAG/SCC proposal, current-state blockers, A PlanVault reservation and replay/substitution defense, ExternalIntent recovery ledger, and graph-state Broker routes.

Missing authority: the current Registry/Provider API exposes a capability descriptor plus aliases, tags and object types. It has no trusted typed relation from a historical production capability to the native capability that prepares a fresh plan for that production. Dynamic provider metadata is explicitly untrusted. C therefore refuses to infer preparation from a name, tag, provider substitution or stored command arguments.

Required upstream contract: a host-validated relation that binds production descriptor/provider generation to a preparation capability/descriptor and remains stable in the same catalog snapshot. Only after this exists can C expose native rebuild preparation through A's controller and the existing Broker. No generic project.rebuild.execute or second scheduler should be added.

## C13 — Blender -> GLB -> Godot

E source d80471b9ceb828a2a531dfac9eaa4e970ea589a9 has successful native Blender evidence. C provides ReceiptAdapter for mutating production receipts and RevisionAdapter/AdmittedRevision for read-only native import/readback without fabricating a derivation.

D's frozen candidates still fail the native-authoring provider handshake before protocol Hello; dependent cross-app gates are skipped/non-green. A c-receipt.json emitted during a failing native run is not sufficient acceptance. C13 requires one exact D candidate whose required native authoring and dependent Blender-GLB-Godot oracle both pass and whose host admits the real receipts/observations.

## C14 — Motion / AV / audio

A current AV model exposes AudioConsumerReceipt, verified MediaArtifact data, cue/plan binding and publication through A's own authority. B owns audio authoring/runtime evidence. C does not create another publication pointer and does not promote the B technical fixture itself into graph causality.

Required integrated path: after A accepts the real B/native audio receipt and AV publication, the trusted host maps the actual consumed audio/master/publication resources to C LogicalAssetId/RevisionPin values and admits a C ExecutionReceipt pinned to the dispatched capability/descriptor/runtime/plan/parameters plus determining cue/audio/runtime/publication contract digests. Incomplete dependency/effect coverage remains UNKNOWN.

## Non-claims

None of these blockers reduce the validity of the portable Project Graph model/store/query/Skill gates. Conversely, green portable gates cannot close these native rows. PROJECT_GRAPH_READY and R16 remain false until the appropriate integrated role/candidate supplies their evidence.
