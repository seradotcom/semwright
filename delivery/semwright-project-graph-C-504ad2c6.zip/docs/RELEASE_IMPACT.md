# Release impact — role C

Status: development component in draft PR #173. No release/tag/main merge, production rollout, native readiness or R16 closure is requested.

The workspace gains `semwright-project-graph`; its default surface is the portable identity/model/query/rebuild library. Optional `store` adds pinned rusqlite 0.40.2 with bundled SQLite and the existing platform-services boundary. The remote-resolved lock introduced only the documented store dependency closure, without upgrading unrelated workspace packages. Registry and Skills are development dependencies for actual package/conformance tests, not a second runtime authority.

A C0 is consumed unchanged. The generic ScopedRoot trait receives an additive object-safe observation method with a conservative default Unsupported implementation. Linux implements bounded native instance observation. Existing scoped read/write methods are unchanged. Rust consumers should rebuild coherently from the integrated SHA; this is not a binary-ABI compatibility promise.

Private graph schema 1 is new. No application files or existing workflow stores are migrated. The event journal preserves revisions/activities and allows explicit index reconstruction; unrecognized schema versions fail closed. The additive `revision_candidate` wire schema introduces no stored authority: AssetRevision/Owner/ProjectId are supplied by trusted admission, not candidate JSON. Portable imports never acquire local owner identity, trusted receipts/revisions, locators or CURRENT state.

The candidate adds 16 bounded `project.*` core descriptors, including read-only bounded provenance and explicit graph-private GC preview/collect. Generic CLI/MCP execution gateways reach them through the same Broker as existing built-ins; no second API authority is added. Mutations require explicit `project.manage` and a named filesystem read grant. The daemon binds private stores to a versioned OS-user principal rather than a client session. The continuity Skill now requires the actual graph descriptors; its examples still execute zero project operations.

Required remaining release gates include the exact-source Broker/daemon integration lane, native receipt adapters, wiring the ExternalIntent ledger around real application-changing rebuild dispatch/reconciliation, D/E Blender→GLB→Godot and A/B AV/audio receipt flows, clean-room native installation, applicable non-Linux acceptance, dependency audit/license gates and final integrated-candidate regression. Fuzz smoke and an internal adversarial agent cannot replace those gates or R16.
