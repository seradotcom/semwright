# Semwright Project Graph C verification

Source SHA: 504ad2c6632305b580b51703a60b0a194865780d
Baseline SHA: b736d41b61c4a4146c9e75c16796e251b025e69f
Contract SHA: 26602e4b25929be869d69ef28fef4dd9713180d7
PR: #173

This package proves the portable C candidate only for the exact successful runs listed in C_EVIDENCE_FINAL.json.
It does NOT assert PROJECT_GRAPH_READY because C09, C13 and C14 remain blocked.

Reproduction:
1. Review CHANGED_PATHS.txt and COMMITS.txt.
2. Start from exact baseline b736d41b61c4a4146c9e75c16796e251b025e69f.
3. Run git apply --check patches/semwright-project-graph.patch.
4. Apply the patch only in a clean review checkout.
5. Compare the resulting source to 504ad2c6632305b580b51703a60b0a194865780d.
6. Re-run the registered Project Graph lane and applicable Windows/Quality/Packaging gates on the same SHA.

The Project Graph artifact is preserved with its archive SHA-256. The included Skill bundle is the exact one produced by the candidate run.
No target/, .git, credentials, user project files or native render outputs are included.
