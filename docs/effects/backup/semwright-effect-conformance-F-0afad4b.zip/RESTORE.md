# F source backup — not an accepted release

This is a reconstructive patch ZIP, not a full repository checkout. F_SOURCE.patch contains all 42 F-owned implementation, contract, test, native harness, CI and documentation files plus the Cargo.toml/Cargo.lock deltas. SOURCE_MANIFEST.json records exact source hashes.

Source: 0afad4b4ceac59434ae938d246f96d8d4351498e
Patch base: 6ee52b428310370d3ad438a13964086a63f48367
A contract: 26602e4b25929be869d69ef28fef4dd9713180d7
PR: https://github.com/seradotcom/semwright/pull/172

Prefer continuing the existing effect-conformance worktree and branch. Do not reset it, change another branch, or apply this patch over existing F files. In a separate owned worktree based exactly on the patch base, run git apply --check /path/F_SOURCE.patch before git apply /path/F_SOURCE.patch. Check all restored file hashes against SOURCE_MANIFEST.json. Source-only reconstruction was already verified in a disposable temporary folder; that is not a build, installation, native acceptance or security claim.

All Cargo/build/test, Godot, Blender, fuzz and mutation workloads belong in GitHub-hosted Actions. Use the registered selector in scripts/effects/lane.json and verify the exact tested SHA. Re-running an older workflow does not test newer code. Reports distinguish contractual consumers, native-adapter conformance and production Broker E2E.

Historical docs and CI receipts apply only to their stated source SHA. Packaging establishes no current-SHA acceptance. Owner A review, D/E production adapters, final A/B/C receipts, native negative cases, portability, targeted mutations, audit/license and clean-install evidence must be checked separately. No main merge, release, demo, R16 closure, official trust badge, global noninterference, crash durability or cross-app rollback is authorized by this backup.
